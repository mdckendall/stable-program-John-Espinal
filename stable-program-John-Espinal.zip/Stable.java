import java.util.ArrayList;

public class Stable{
  String address;

  public Stable(String address){
    this.address = address;
  }
  public String getAddress(){
    return address;
  }
  public void setAddress(String address){
    this.address = address;
  }
  public static void main(String[] args){
  ArrayList arrayList = new ArrayList();
 }
}   
  
  
