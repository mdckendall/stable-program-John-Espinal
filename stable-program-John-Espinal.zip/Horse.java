public class Horse {
  String hn;
  double w;
  boolean t = false;

  public Horse(String hn, double w, boolean t){
    this.hn = hn;
    this.w = w;
    this.t = t;
    
  }
  public String getHn(){
    return hn;
  }
  public void setHn(String hn){
    this.hn = hn;
  }
  public double getW(){
    return w;
  } 
  public void setW(double w){
    this.w = w;
  }
  public boolean isT(){
    return t;
  }
  public void setT(boolean t){
    this.t = t;
  }
}